from django.apps import AppConfig

class CleanserAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cleanser_app'
